package com.capgemini.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.capgemini.ems.dto.Employee;
import com.capgemini.ems.exception.EmsException;
import com.capgemini.ems.util.DbUtil;

public class EmployeeDaoImpl implements EmployeeDao {

	@Override
	public int addEmployee(Employee emp) throws EmsException {
		
		Connection con=null;
		int data=0;
		DateFormat df = new SimpleDateFormat("dd-MM-YY");
		Date parseDob=null;
		Date parseDoj=null;
		
		try {
			parseDob = df.parse(emp.getEmp_Date_of_Birth());
			parseDoj = df.parse(emp.getEmp_Date_of_Joining());
		} catch (ParseException e1) {
						e1.printStackTrace();
		}
		

		java.sql.Date dateDob = new java.sql.Date(parseDob.getTime());
		java.sql.Date dateDoj = new java.sql.Date(parseDoj.getTime());
		
		String emp_Id = getSeqEmpId() + "";
		try {
			con=DbUtil.getConnection();
			String query="INSERT INTO EMPLOYEE VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement pstm=con.prepareStatement(query);
			pstm.setString(1, emp_Id);
			pstm.setString(2,emp.getEmp_First_Name());
			pstm.setString(3,emp.getEmp_Last_Name());
			pstm.setDate(4,dateDob);
			pstm.setDate(5,dateDoj);
			pstm.setInt(6,emp.getEmp_Dept_Id());
			pstm.setString(7,emp.getEmp_Grade());
			pstm.setString(8,emp.getEmp_Designation());
			pstm.setInt(9,emp.getEmp_Basic());
			pstm.setString(10,emp.getEmp_Gender());
			pstm.setString(11,emp.getEmp_Marital_Status());
			pstm.setString(12,emp.getEmp_Home_Address());
			pstm.setString(13,emp.getEmp_Contact_Num());
			int status=pstm.executeUpdate();
			if (status==1){
			data = Integer.parseInt(emp_Id);
				//myLogger.info("Data inserted id..."+data);
			}
		} catch (EmsException | SQLException e) {

			e.printStackTrace();
			//myLogger.info("problem in connection............");
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				//myLogger.info("problem in close");
			}

		}
		return data;
		 
		
	}
	
	public static int getSeqEmpId(){
	  	int empId = 0;
		String query4="SELECT sequence_empId.nextval FROM DUAL";
		Connection con=null;
		try {
			con=DbUtil.getConnection();
			Statement st=con.createStatement();
			ResultSet res=st.executeQuery(query4);
			while(res.next()){
				empId=res.getInt(1);
			}
		} catch (EmsException | SQLException e) {

			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

		return empId;
	}
	
 public static void main(String[] args) {
	 EmployeeDaoImpl dao=new EmployeeDaoImpl();
	 
	 Employee e=new Employee();
	 
	 e.setEmp_First_Name("Lalak");
	 e.setEmp_Last_Name("Garg");
	 e.setEmp_Date_of_Birth("06-06-1994");
	 e.setEmp_Date_of_Joining("12-09-2016");
	 e.setEmp_Basic(10000);
	 e.setEmp_Contact_Num("9823456767");
	 e.setEmp_Dept_Id(100);
	 e.setEmp_Designation("Enginneer");
	 e.setEmp_Gender("f");
	 e.setEmp_Grade("A");
	 e.setEmp_Home_Address("pune");
	 e.setEmp_Marital_Status("unmarried");
	 try {
		dao.addEmployee(e);
	} catch (EmsException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	
}

}
