package com.capgemini.ems.dao;

import com.capgemini.ems.dto.Employee;
import com.capgemini.ems.exception.EmsException;

public interface EmployeeDao {
	
	public int addEmployee(Employee emp) throws EmsException;
	

}
