package com.capgemini.dao;

public interface UserDao {
	
	String usrCheck(String usrName,String usrPass);

}
