package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.exception.EmsException;
import com.capgemini.util.DbUtil;

public class UsrDaoImpl implements UserDao {

	@Override
	public String usrCheck(String usrName, String usrPass) {
		String userType = null;
		String qry = "SELECT userType FROM User_Master WHERE userName=? AND UserPassword=?";
		Connection conn = null;
		try {
			conn = DbUtil.getConnection();
			PreparedStatement pstm=conn.prepareStatement(qry);
			pstm.setString(1, usrName);
			pstm.setString(2,usrPass);

			ResultSet res=pstm.executeQuery(qry);
			while(res.next()){
				userType=res.getString(1);
			}
		}
			
		 catch (SQLException | EmsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userType;
	}

}
