package com.capgemini.ems.service;

import java.util.List;

import com.capgemini.ems.dto.Employee;
import com.capgemini.ems.exception.EmsException;

public interface EmployeeService {
	public int addEmployee(Employee emp) throws EmsException;

	public List<Employee> showAllEmployees() throws EmsException;

	public void modifyEmployee(Employee emp) throws EmsException;
	
	public boolean validationsOnEmployee(Employee emp)throws EmsException;

}
