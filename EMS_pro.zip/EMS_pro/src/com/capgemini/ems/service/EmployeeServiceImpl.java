package com.capgemini.ems.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.ems.dao.EmployeeDao;
import com.capgemini.ems.dao.EmployeeDaoImpl;
import com.capgemini.ems.dto.Employee;
import com.capgemini.ems.exception.EmsException;

public class EmployeeServiceImpl implements EmployeeService {

	EmployeeDao empDao = new EmployeeDaoImpl();

	@Override
	public int addEmployee(Employee emp) throws EmsException {
		boolean isValid = this.validationsOnEmployee(emp);
		if (isValid) {
			return empDao.addEmployee(emp);
		} else {
			throw new EmsException("Please match the formats");
		}
	}

	@Override
	public List<Employee> showAllEmployees() throws EmsException {

		return empDao.showAllEmployees();
	}

	@Override
	public void modifyEmployee(Employee emp) throws EmsException {
		boolean isValidDetails = this.validationsOnEmployee(emp);
		if (isValidDetails) {
			empDao.modifyEmployee(emp);
		} else {
			throw new EmsException("Validation Fail");
		}

	}

	@Override
	public boolean validationsOnEmployee(Employee emp) throws EmsException {
		String emp_Id = emp.getEmp_Id();
		String emp_First_Name = emp.getEmp_First_Name();
		String emp_Last_Name = emp.getEmp_Last_Name();
		String emp_Date_of_Birth = emp.getEmp_Date_of_Birth();
		String emp_Date_of_Joining = emp.getEmp_Date_of_Joining();
		// int emp_Dept_Id = emp;
		// String emp_Grade = emp.getEmp_Grade();
		String emp_Designation = emp.getEmp_Designation();
		// int emp_Basic = emp.getEmp_Basic();
		// String emp_Gender = emp.getEmp_Gender();
		// String emp_Marital_Status = emp.getEmp_Marital_Status();
		String emp_Home_Address = emp.getEmp_Home_Address();
		String emp_Contact_Num = emp.getEmp_Contact_Num();

		boolean isValidId = this.validationOnId(emp_Id);
		if (isValidId) {
			boolean isValidFname = this.validationOnFname(emp_First_Name);
			if (isValidFname) {
				boolean isValidLname = this.validationOnLname(emp_Last_Name);
				if (isValidLname) {
					boolean isValidDob = this
							.validationOnDateOfBirth(emp_Date_of_Birth);
					if (isValidDob) {
						boolean isValidDoj = this
								.validationOnDateofJoining(emp_Date_of_Joining);
						if (isValidDoj) {
							boolean isValidDesignation = this
									.validationOnDesignation(emp_Designation);
							if (isValidDesignation) {
								boolean isValidHomeAddress = this
										.validationOnHomeAddress(emp_Home_Address);
								if (isValidHomeAddress) {
									boolean isValidEmpContactNum = this
											.validationOnEmpContactNum(emp_Contact_Num);
									if (isValidEmpContactNum) {
										return true;
									}
								}
							}
						}
					}
				}
			}
		}
		return false;
	}

	/*
	 * This validation is for Phone number of employee which is required to be a
	 * 10 digit number (Basically of India)
	 */
	private boolean validationOnEmpContactNum(String emp_Contact_Num) {
		String regex = "^[7-9][0-9]{9}$";
		boolean isValid = Pattern.matches(regex, emp_Contact_Num);
		if (isValid) {
			return true;
		} else {
			return false;
		}
	}

	/*
	 * This validation is for Home Address of employee. Employees Home Address
	 * can be optional
	 */

	private boolean validationOnHomeAddress(String emp_Home_Address) {
		String regex = "[A-Z a-z 0-9]";
		boolean isValid = Pattern.matches(regex, emp_Home_Address);
		if (isValid) {
			return true;
		} else {
			return false;
		}
	}

	/*
	 * This validation is for Designation where the designation has to be in
	 * alphabetical form and cannot be null
	 */

	private boolean validationOnDesignation(String emp_Designation) {
		String regex = "[A-Z a-z]{1,50}";
		boolean isValid = Pattern.matches(regex, emp_Designation);
		if (isValid) {
			return true;
		} else {
			return false;
		}
	}

	/*
	 * Validation for date of joining of employee where date of joining must be
	 * less than or equal to 58
	 */

	private boolean validationOnDateofJoining(String emp_Date_of_Joining)
			throws EmsException {
		Date parsedDate = null;
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HHmmss");

		try {
			parsedDate = formatter.parse(emp_Date_of_Joining);
			@SuppressWarnings("deprecation")
			int year = (new java.util.Date()).getYear() - parsedDate.getYear();
			// System.out.println(year);
			if (year <= 58) {
				return true;
			}

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			throw new EmsException(
					" Error in Date of joining format XX/XX/XXXX");
		}
		return false;
	}

	/*
	 * Validation for date of birth and the age of employee must be greater than
	 * 18
	 */

	private boolean validationOnDateOfBirth(String emp_Date_of_Birth) {
		// String regex = "([0-9]{2})/([0-9]{2})/([0-9]{4})";
		// boolean isValid = Pattern.matches(regex, emp_Date_of_Birth);

		Date parsedDate = null;
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HHmmss");
		try {
			parsedDate = formatter.parse(emp_Date_of_Birth);
			@SuppressWarnings("deprecation")
			int year = (new java.util.Date()).getYear() - parsedDate.getYear();
			// System.out.println(year);
			if (year >= 18) {
				return true;
			}

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;

	}

	/*
	 * Validation on the First name of employee where name can be alphabets only
	 */

	private boolean validationOnFname(String emp_First_Name) {
		String regex = "[A-Z a-z]{1,100}";
		boolean isValid = Pattern.matches(regex, emp_First_Name);
		if (isValid) {
			return true;
		} else {
			return false;
		}

	}

	/*
	 * Validation for Last name where name can be alphabets only
	 */

	private boolean validationOnLname(String emp_Last_Name) {
		String regex = "[A-Z a-z]{1,100}";
		boolean isValid = Pattern.matches(regex, emp_Last_Name);
		if (isValid) {
			return true;
		} else {
			return false;
		}

	}

	/* Validation on Employee's Id where the ID has to be a 6 digit number */

	public boolean validationOnId(String emp_Id) {
		String regex = "[1-9]{6}";
		boolean isValid = Pattern.matches(regex, emp_Id);
		if (isValid) {
			return true;
		} else {
			return false;
		}

	}

}
