package com.capgemini.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.capgemini.ems.dto.Employee;
import com.capgemini.ems.exception.EmsException;
import com.capgemini.ems.util.DbUtil;


public class EmployeeDaoImpl implements EmployeeDao {

	@Override
	public int addEmployee(Employee emp) throws EmsException {
		
		Connection con=null;
		int data=0;
		DateFormat df = new SimpleDateFormat("dd-MM-YY");
		Date parseDob=null;
		Date parseDoj=null;
		
		try {
			parseDob = df.parse(emp.getEmp_Date_of_Birth());
			parseDoj = df.parse(emp.getEmp_Date_of_Joining());
		} catch (ParseException e1) {
						e1.printStackTrace();
		}
		

		java.sql.Date dateDob = new java.sql.Date(parseDob.getTime());
		java.sql.Date dateDoj = new java.sql.Date(parseDoj.getTime());
		
		String emp_Id = getSeqEmpId() + "";
		try {
			con=DbUtil.getConnection();
			String query="INSERT INTO EMPLOYEE VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement pstm=con.prepareStatement(query);
			pstm.setString(1, emp_Id);
			pstm.setString(2,emp.getEmp_First_Name());
			pstm.setString(3,emp.getEmp_Last_Name());
			pstm.setDate(4,dateDob);
			pstm.setDate(5,dateDoj);
			pstm.setInt(6,emp.getEmp_Dept_Id());
			pstm.setString(7,emp.getEmp_Grade());
			pstm.setString(8,emp.getEmp_Designation());
			pstm.setInt(9,emp.getEmp_Basic());
			pstm.setString(10,emp.getEmp_Gender());
			pstm.setString(11,emp.getEmp_Marital_Status());
			pstm.setString(12,emp.getEmp_Home_Address());
			pstm.setString(13,emp.getEmp_Contact_Num());
			int status=pstm.executeUpdate();
			if (status==1){
			data = Integer.parseInt(emp_Id);
				//myLogger.info("Data inserted id..."+data);
			}
		} catch (EmsException | SQLException e) {

			e.printStackTrace();
			//myLogger.info("problem in connection............");
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				//myLogger.info("problem in close");
			}

		}
		return data;
		 
		
	}
	
	public static int getSeqEmpId(){
	  	int empId = 0;
		String query4="SELECT sequence_empId.nextval FROM DUAL";
		Connection con=null;
		try {
			con=DbUtil.getConnection();
			Statement st=con.createStatement();
			ResultSet res=st.executeQuery(query4);
			while(res.next()){
				empId=res.getInt(1);
			}
		} catch (EmsException | SQLException e) {

			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

		return empId;
	}
	
 public static void main(String[] args) {
	 EmployeeDaoImpl dao=new EmployeeDaoImpl();
	 
	 Employee e=new Employee();
	 
	 e.setEmp_First_Name("Lalan");
	 e.setEmp_Last_Name("Garge");
	 e.setEmp_Date_of_Birth("06-06-1993");
	 e.setEmp_Date_of_Joining("06-09-2016");
	 e.setEmp_Basic(10000);
	 e.setEmp_Contact_Num("9823456767");
	 e.setEmp_Dept_Id(101);
	 e.setEmp_Designation("Enginneer");
	 e.setEmp_Gender("f");
	 e.setEmp_Grade("A");
	 e.setEmp_Home_Address("pune");
	 e.setEmp_Marital_Status("u");
	 e.setEmp_Id("103");
	 try {
		 dao.modifyEmployee(e);
		
	} catch (EmsException e2) {
		// TODO Auto-generated catch block
		e2.printStackTrace();
	}
	
	
}

@Override
public List<Employee> showAllEmployees() throws EmsException {
	
	List<Employee> myList=new ArrayList<Employee>();
	Connection conn=null;
try {
	 conn=DbUtil.getConnection();
	String quer1="SELECT * FROM EMPLOYEE";
	Statement stml=conn.createStatement();
	ResultSet res=stml.executeQuery(quer1);
	while(res.next()){
		Employee emp=new Employee();
		emp.setEmp_Id(res.getString("Emp_Id"));
		emp.setEmp_First_Name(res.getString("Emp_First_Name"));
		emp.setEmp_Last_Name(res.getString("Emp_Last_Name"));
		emp.setEmp_Date_of_Birth(res.getString("Emp_Date_Of_Birth"));
		emp.setEmp_Date_of_Joining(res.getString("Emp_Date_Of_Joining"));
		emp.setEmp_Dept_Id(res.getInt("Emp_Dept_Id"));
		emp.setEmp_Grade(res.getString("Emp_Grade"));
		emp.setEmp_Designation(res.getString("Emp_Designation"));
		emp.setEmp_Basic(res.getInt("Emp_Basic"));
		emp.setEmp_Gender(res.getString("Emp_Gender"));
		emp.setEmp_Marital_Status(res.getString("Emp_Marital_Status"));
		emp.setEmp_Home_Address(res.getString("Emp_Home_Address"));
		emp.setEmp_Contact_Num(res.getString("Emp_Contact_Num"));
		
		
		myList.add(emp);
	}
	//myLogger.info("List of data.."+myList);
	
} catch (EmsException | SQLException e) {
	//myLogger.info("Error Message"+e.getMessage(),e);
	throw new EmsException("show errors");
}finally{
	try {
		conn.close();
	} catch (SQLException e) {
		
		e.printStackTrace();
	}
}

return myList;
}

@Override
public void modifyEmployee(Employee emp) throws EmsException {
	DateFormat df = new SimpleDateFormat("dd-MM-YY");
	Date parseDob=null;
	Date parseDoj=null;
	
	try {
		parseDob = df.parse(emp.getEmp_Date_of_Birth());
		parseDoj = df.parse(emp.getEmp_Date_of_Joining());
	} catch (ParseException e1) {
					e1.printStackTrace();
	}
	
	java.sql.Date dateDob = new java.sql.Date(parseDob.getTime());
	java.sql.Date dateDoj = new java.sql.Date(parseDoj.getTime());
	try(Connection con=DbUtil.getConnection())
	{
		PreparedStatement pstm=
				con.prepareStatement("UPDATE Employee SET Emp_First_Name=?,Emp_Last_Name=?,Emp_Date_Of_Birth=?,Emp_Date_Of_Joining=?,"
						+ "Emp_Dept_Id=?,Emp_Grade=?,Emp_Designation=?,Emp_Basic=?,Emp_Gender=?,Emp_Marital_Status=?,"
						+ "Emp_Home_Address=?,Emp_Contact_Num=? where Emp_Id=?");
		
		pstm.setString(1,emp.getEmp_First_Name());
		pstm.setString(2,emp.getEmp_Last_Name());
		pstm.setDate(3,dateDob);
		pstm.setDate(4,dateDoj);
		pstm.setInt(5,emp.getEmp_Dept_Id());
		pstm.setString(6,emp.getEmp_Grade());
		pstm.setString(7,emp.getEmp_Designation());
		pstm.setInt(8,emp.getEmp_Basic());
		pstm.setString(9,emp.getEmp_Gender());
		pstm.setString(10,emp.getEmp_Marital_Status());
		pstm.setString(11,emp.getEmp_Home_Address());
		pstm.setString(12,emp.getEmp_Contact_Num());
		pstm.setString(13,emp.getEmp_Id());
		pstm.executeUpdate();
		
	}catch(Exception e){
		throw new EmsException(e);
		
	}
	
}

}
