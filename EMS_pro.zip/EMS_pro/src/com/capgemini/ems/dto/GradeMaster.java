package com.capgemini.ems.dto;

import java.io.Serializable;

public class GradeMaster implements Serializable{
	

	private static final long serialVersionUID = 1L;
	private String grade_Code;
	private String description;
	private int min_Salary;
	private int max_Salary;
	
	public GradeMaster() {
		// TODO Auto-generated constructor stub
	}

	public String getGrade_Code() {
		return grade_Code;
	}

	public void setGrade_Code(String grade_Code) {
		this.grade_Code = grade_Code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getMin_Salary() {
		return min_Salary;
	}

	public void setMin_Salary(int min_Salary) {
		this.min_Salary = min_Salary;
	}

	public int getMax_Salary() {
		return max_Salary;
	}

	public void setMax_Salary(int max_Salary) {
		this.max_Salary = max_Salary;
	}

	public GradeMaster(String grade_Code, String description, int min_Salary,
			int max_Salary) {
		super();
		this.grade_Code = grade_Code;
		this.description = description;
		this.min_Salary = min_Salary;
		this.max_Salary = max_Salary;
	}

	@Override
	public String toString() {
		return "GradeMaster [grade_Code=" + grade_Code + ", description="
				+ description + ", min_Salary=" + min_Salary + ", max_Salary="
				+ max_Salary + "]";
	}

	
	
	

}
