package com.cg.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class DirectController
 */
@WebServlet("/DirectController")
public class DirectController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}

	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		ServiceClass serviceObj = new ServiceClass();
		/* Service object*/
		String action = request.getParameter("action");
		String searchType = request.getParameter("searchType");
		switch(action) {
		case "login": {
			String usrName = request.getParameter("usrName");
			String usrPass = request.getParameter("usrPass");

			String usrType = serviceObj.serviceMethod(usrName,usrPass);
			/*	Must return type of user or null if invalid user*/

			if(usrType == null) {
				request.setAttribute("errMsg", "Invalid username/password");
				request.getRequestDispatcher("errorScreenMain").forward(request, response);
				break;
			}
			else {
				HttpSession session = request.getSession(true);
				if(usrType == "admin") {
					request.getRequestDispatcher("adminMainScreen").forward(request, response);
				}
				else if(usrType == "user") {
					request.getRequestDispatcher("userMainScreen").forward(request, response);
				}
			}
		}
		break;
		case "usrSearch": {
			switch(searchType) {
			case "id": {
				String usrId = request.getParameter("id");
				Map<String,String> usrMap = new HashMap<>();
				usrMap = serviceObj.serviceMethod(usrId);

				if(usrMap == null) {
					request.setAttribute("errMsg", "No employees with that id");
					request.getRequestDispatcher("errorScreenUser").forward(request, response);
					break;
				}
				else {
					request.setAttribute("usrId", usrMap.get("empId"));
					request.setAttribute("usrfName", usrMap.get("empfName"));
					request.setAttribute("usrlName", usrMap.get("emplName"));
					request.setAttribute("usrDOB", usrMap.get("empDOB"));
					request.setAttribute("usrDOJ", usrMap.get("empDOJ"));
					request.setAttribute("usrDeptId", usrMap.get("empDeptId"));
					request.setAttribute("usrGrade", usrMap.get("empGrade"));
					request.setAttribute("usrDesig", usrMap.get("empDesig"));
					request.setAttribute("usrBasicPay", usrMap.get("empBasicPay"));
					request.setAttribute("usrGender", usrMap.get("empGender"));
					request.setAttribute("usrMaritalStatus", usrMap.get("empMaritalStatus"));
					request.setAttribute("usrHoAddr", usrMap.get("empHoAddr"));
					request.setAttribute("usrConNum", usrMap.get("empConNum"));

					request.getRequestDispatcher("displayScreenUser").forward(request, response);
					break;
				}
			}
			break;
			case "fName": {
					String fName = request.getParameter("fName");
					Map<String,String> usrMap = new HashMap<>();
					usrMap = serviceObj.serviceMethod(fName);
	
					if(usrMap == null) {
						request.setAttribute("errMsg", "No employees with that first name");
						request.getRequestDispatcher("errorScreenUser").forward(request, response);
						break;
					}
					else {
						request.setAttribute("usrId", usrMap.get("empId"));
						request.setAttribute("usrfName", usrMap.get("empfName"));
						request.setAttribute("usrlName", usrMap.get("emplName"));
						request.setAttribute("usrDOB", usrMap.get("empDOB"));
						request.setAttribute("usrDOJ", usrMap.get("empDOJ"));
						request.setAttribute("usrDeptId", usrMap.get("empDeptId"));
						request.setAttribute("usrGrade", usrMap.get("empGrade"));
						request.setAttribute("usrDesig", usrMap.get("empDesig"));
						request.setAttribute("usrBasicPay", usrMap.get("empBasicPay"));
						request.setAttribute("usrGender", usrMap.get("empGender"));
						request.setAttribute("usrMaritalStatus", usrMap.get("empMaritalStatus"));
						request.setAttribute("usrHoAddr", usrMap.get("empHoAddr"));
						request.setAttribute("usrConNum", usrMap.get("empConNum"));
	
						request.getRequestDispatcher("displayScreenUser").forward(request, response);
						break;
				}
			}
			break;
			case "lName": {
					String lName = request.getParameter("lName");
					Map<String,String> usrMap = new HashMap<>();
					usrMap = serviceObj.serviceMethod(lName);
	
					if(usrMap == null) {
						request.setAttribute("errMsg", "No employees with that last name");
						request.getRequestDispatcher("errorScreenUser").forward(request, response);
						break;
					}
					else {
						request.setAttribute("usrId", usrMap.get("empId"));
						request.setAttribute("usrfName", usrMap.get("empfName"));
						request.setAttribute("usrlName", usrMap.get("emplName"));
						request.setAttribute("usrDOB", usrMap.get("empDOB"));
						request.setAttribute("usrDOJ", usrMap.get("empDOJ"));
						request.setAttribute("usrDeptId", usrMap.get("empDeptId"));
						request.setAttribute("usrGrade", usrMap.get("empGrade"));
						request.setAttribute("usrDesig", usrMap.get("empDesig"));
						request.setAttribute("usrBasicPay", usrMap.get("empBasicPay"));
						request.setAttribute("usrGender", usrMap.get("empGender"));
						request.setAttribute("usrMaritalStatus", usrMap.get("empMaritalStatus"));
						request.setAttribute("usrHoAddr", usrMap.get("empHoAddr"));
						request.setAttribute("usrConNum", usrMap.get("empConNum"));
	
						request.getRequestDispatcher("displayScreenUser").forward(request, response);
						break;
				}
			}
			break;
			case "dept": {
					List<String> dept=new ArrayList<String>();
					String values[] = request.getParameterValues("dept");
					if(values!=null) {
						for(int i=0;i<values.length;i++) {
							dept.add(values[i]);
						}
					}
					else {
						request.setAttribute("errMsg", "No department selected");
						request.getRequestDispatcher("errorScreenUser").forward(request, response);
						break;
					}
					
					Map<String,String> usrMap = new HashMap<>();
					usrMap = serviceObj.serviceMethod(dept);

					if(usrMap == null) {
						request.setAttribute("errMsg", "No employees in selected department(s)");
						request.getRequestDispatcher("errorScreenUser").forward(request, response);
						break;
					}
					else {
						request.setAttribute("usrId", usrMap.get("empId"));
						request.setAttribute("usrfName", usrMap.get("empfName"));
						request.setAttribute("usrlName", usrMap.get("emplName"));
						request.setAttribute("usrDOB", usrMap.get("empDOB"));
						request.setAttribute("usrDOJ", usrMap.get("empDOJ"));
						request.setAttribute("usrDeptId", usrMap.get("empDeptId"));
						request.setAttribute("usrGrade", usrMap.get("empGrade"));
						request.setAttribute("usrDesig", usrMap.get("empDesig"));
						request.setAttribute("usrBasicPay", usrMap.get("empBasicPay"));
						request.setAttribute("usrGender", usrMap.get("empGender"));
						request.setAttribute("usrMaritalStatus", usrMap.get("empMaritalStatus"));
						request.setAttribute("usrHoAddr", usrMap.get("empHoAddr"));
						request.setAttribute("usrConNum", usrMap.get("empConNum"));

						request.getRequestDispatcher("displayScreenUser").forward(request, response);
						break;
				}
			}
			break;
			case "grade": {
				List<String> grade=new ArrayList<String>();
				String values[] = request.getParameterValues("grade");
				if(values!=null) {
					for(int i=0;i<values.length;i++) {
						grade.add(values[i]);
					}
				}
					else {
						request.setAttribute("errMsg", "No grade selected");
						request.getRequestDispatcher("errorScreenUser").forward(request, response);
						break;
					}
					
					Map<String,String> usrMap = new HashMap<>();
					usrMap = serviceObj.serviceMethod(grade);
	
					if(usrMap == null) {
						request.setAttribute("errMsg", "No employees with selected grade(s)");
						request.getRequestDispatcher("errorScreenUser").forward(request, response);
						break;
					}
					else {
						request.setAttribute("usrId", usrMap.get("empId"));
						request.setAttribute("usrfName", usrMap.get("empfName"));
						request.setAttribute("usrlName", usrMap.get("emplName"));
						request.setAttribute("usrDOB", usrMap.get("empDOB"));
						request.setAttribute("usrDOJ", usrMap.get("empDOJ"));
						request.setAttribute("usrDeptId", usrMap.get("empDeptId"));
						request.setAttribute("usrGrade", usrMap.get("empGrade"));
						request.setAttribute("usrDesig", usrMap.get("empDesig"));
						request.setAttribute("usrBasicPay", usrMap.get("empBasicPay"));
						request.setAttribute("usrGender", usrMap.get("empGender"));
						request.setAttribute("usrMaritalStatus", usrMap.get("empMaritalStatus"));
						request.setAttribute("usrHoAddr", usrMap.get("empHoAddr"));
						request.setAttribute("usrConNum", usrMap.get("empConNum"));
	
						request.getRequestDispatcher("displayScreenUser").forward(request, response);
						break;
				}
			}
			break;
			case "maritalStatus": {
					List<String> marStat=new ArrayList<String>();
					String values[] = request.getParameterValues("marStat");
					if(values!=null) {
						for(int i=0;i<values.length;i++) {
							marStat.add(values[i]);
						}
					}
					else {
						request.setAttribute("errMsg", "No maritial status selected");
						request.getRequestDispatcher("errorScreenUser").forward(request, response);
						break;
					}
					
					Map<String,String> usrMap = new HashMap<>();
					usrMap = serviceObj.serviceMethod(marStat);
	
					if(usrMap == null) {
						request.setAttribute("errMsg", "No employees with selected maritial status");
						request.getRequestDispatcher("errorScreenUser").forward(request, response);
						break;
					}
					else {
						request.setAttribute("usrId", usrMap.get("empId"));
						request.setAttribute("usrfName", usrMap.get("empfName"));
						request.setAttribute("usrlName", usrMap.get("emplName"));
						request.setAttribute("usrDOB", usrMap.get("empDOB"));
						request.setAttribute("usrDOJ", usrMap.get("empDOJ"));
						request.setAttribute("usrDeptId", usrMap.get("empDeptId"));
						request.setAttribute("usrGrade", usrMap.get("empGrade"));
						request.setAttribute("usrDesig", usrMap.get("empDesig"));
						request.setAttribute("usrBasicPay", usrMap.get("empBasicPay"));
						request.setAttribute("usrGender", usrMap.get("empGender"));
						request.setAttribute("usrMaritalStatus", usrMap.get("empMaritalStatus"));
						request.setAttribute("usrHoAddr", usrMap.get("empHoAddr"));
						request.setAttribute("usrConNum", usrMap.get("empConNum"));
	
						request.getRequestDispatcher("displayScreenUser").forward(request, response);
						break;
				}
			}//close of inner case
			}//close of inner switch
		}//close of outer case
		case "adminChoice" : {
				String adminChoice = request.getParameter("choice");
				
				switch(adminChoice) {
				case "add" : {
					List<String> deptNames = new ArrayList<>();
					deptNames = serviceObj.serviceMethod();
					request.setAttribute("ListOfDepts", deptNames);
					request.getRequestDispatcher("addNewUser").forward(request, response);
					}
				break;
				case "modify": {
					request.getRequestDispatcher("modifyUser").forward(request, response);	
					}
				break;
				case "display": {
					//find way to fetch 10 user at a time while service sends a list of n users
					request.getRequestDispatcher("modifyUser").forward(request, response);
					}
				break;
				}
			}
		break;
		case "addNewUser":
			Map<String,String> usrMap = new HashMap<String, String>();
			/*List<Map<String,String>> usrList = new ArrayList<>();
			String huhu = request.getParameter("empId");
			usrMap.add("usrEmpId",huhu);*/
			String usrfName = request.getParameter("fName");
			String usrlName = request.getParameter("lName");
			String usrDOJ = request.getParameter("doj");//to be changed to date type in sql
			String usrDOB = request.getParameter("dob");
			String usrDept = request.getParameter("dept");
			String usrGrade = request.getParameter("grade");
			String usrDesig = request.getParameter("designation");
			String usrGender = request.getParameter("gender");
			String usrBasicSal = request.getParameter("basicSal");
			String usrMarStat  =request.getParameter("marStat");
			String usrHoAdd = request.getParameter("homeAddr");
			String usrConNum = request.getParameter("conNum");
			
			break;
		}//outer switch
	}//method
}//servlet
